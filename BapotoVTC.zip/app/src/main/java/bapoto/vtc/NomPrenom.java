package bapoto.vtc;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NomPrenom extends AppCompatActivity {
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nom_prenom);
        getSupportActionBar().hide();

        // code pour le format date//
        this.editText = (EditText) this.findViewById(R.id.ChampDate);
        TextWatcher textWatcher = new DateFormatTextWatcher(this.editText);
        this.editText.addTextChangedListener(textWatcher);

        Button button = findViewById(R.id.boutonNom);
        EditText saisieNom = findViewById(R.id.ChampNom);
        EditText saisieTel = findViewById(R.id.champTel);
        EditText saisieMail = findViewById(R.id.ChampMail);
        EditText saisieDestination = findViewById(R.id.ChampDestination);
        EditText saisieRdv = findViewById(R.id.ChampRDV);
        EditText saisieDate = findViewById(R.id.ChampDate);
        EditText saisieHeure = findViewById(R.id.ChampHeure);
        EditText saisieInfos = findViewById(R.id.ChampInfos);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Champs Obligatoire
                String nom = saisieNom.getText().toString();
                String tel = saisieTel.getText().toString();
                String mail = saisieMail.getText().toString();
                String desti = saisieDestination.getText().toString();
                String rdv = saisieRdv.getText().toString();
                String date = saisieDate.getText().toString();
                String heure = saisieHeure.getText().toString();
                String infos = saisieInfos.getText().toString();

                if (nom.isEmpty())
                {
                    presentModal("Veuillez saisir votre Nom");
                    return;
                }

                if (tel.isEmpty())
                {
                    presentModal("Veuillez saisir votre Numéro de Téléphone");
                    return;
                }
                if (mail.isEmpty())
                {
                    presentModal("Veuillez saisir votre Adresse Mail");
                    return;
                }
                if( desti.isEmpty())
                {
                    presentModal("Veuillez saisir votre Destination");
                    return;
                }
                if (rdv.isEmpty())
                {
                    presentModal("Veuillez saisir le Lieu du RDV");
                    return;
                }
                if (date.isEmpty())
                {
                    presentModal("Veuillez saisir la Date");
                    return;
                }
                if (heure.isEmpty())
                {
                    presentModal("Veuillez saisir l'Heure");
                    return;
                }

                navigateToSummary(nom,tel,mail,desti,rdv,date,heure,infos);


            }
        });
    }

    private void navigateToSummary(String nom,String tel,String mail,String destination, String rdv,
                                   String date, String heure,String infos){
        Intent intent = new Intent(NomPrenom.this, BonDeCommande.class);

        intent.putExtra("nomprenom", nom);
        intent.putExtra("tel",tel);
        intent.putExtra("mail", mail);
        intent.putExtra("destination", destination);
        intent.putExtra("rdv",rdv);
        intent.putExtra("date",date);
        intent.putExtra("heure",heure);
        intent.putExtra("infos",infos);

        startActivity(intent);
    }

    private void presentModal(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
            }
        });
        builder.setTitle("OUPS...");
        builder.setMessage(message);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}


